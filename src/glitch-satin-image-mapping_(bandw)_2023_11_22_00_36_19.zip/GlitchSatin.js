class GlitchSatin {
  constructor() {
    // setup the initial all false grid
    this.grid = []

    this.resetGrid();
  }
  
  resetGrid() {
    // setup the initial all false grid
    for (let i = 0; i < wefts; i++) {
      this.grid[i] = [];
      for (let j = 0; j < warps; j++) {
        this.grid[i][j] = false;
      }
    }
  }
  
  displayGrid() {
    // Loop to draw the mask based on gridColors
    for (let i = 0; i < wefts; i++) {
      for (let j = 0; j < warps; j++) {
        if (this.grid[i][j]) { // mask says black
          fill(0); // Black
        } else { // mask says white
          fill(255); // White
        }
        rect(j * cellSize, i * cellSize, cellSize, cellSize); // Draw the rectangle
      }
    }  
  }
  
  generateGlitch(oddsDenomMin, oddsDenomMax) {
    if (oddsDenomMin > oddsDenomMax) {
      throw new Error('Minimum value cannot be greater than the maximum value.');
    }
    
    this.resetGrid(); // reset this.grid to all false
    const newGrid = [];

    for (let rowIndex = 0; rowIndex < this.grid.length; rowIndex++) {
      let row = this.getRandomRow(this.grid[rowIndex], oddsDenomMin, oddsDenomMax);
      // this.logGaps(row); // Optional: console.log interlacement gaps
      newGrid.push(row);
    }

    this.grid = newGrid;
  }

  getRandomRow(arrRow, minDistance, maxDistance) {
    let gapIndex = this.findLargeGap(arrRow, maxDistance);

    while (gapIndex[0] !== -1 && gapIndex[1] !== -1) {
      let startIndex = gapIndex[0];
      let endIndex = gapIndex[1];
      let randomPos = Math.floor(Math.random() * (endIndex - startIndex)) + startIndex;
      let distance = this.getDistanceToTrue(arrRow, randomPos);
      if (distance > minDistance && randomPos >= 0 && randomPos < arrRow.length) {
        arrRow[randomPos] = true;
      }
      gapIndex = this.findLargeGap(arrRow, maxDistance);
    }

    return arrRow;
  }

  logGaps(arr) {
    let lastTrueIndex = -1;

    for (let i = 0; i < arr.length; i++) {
      if (arr[i]) {
        if (lastTrueIndex === -1) {
          console.log(`Gap length edge: ${i}`);
        } else {
          console.log(`Gap length true: ${i - lastTrueIndex - 1}`);
        }
        lastTrueIndex = i;
      }
    }

    if (lastTrueIndex !== arr.length - 1) {
      console.log(`Gap length edge: ${arr.length - lastTrueIndex - 1}`);
    }
  }

  findLargeGap(arrRow, maxDistance) {
    let startIndex = -1;
    let endIndex = -1;

    for (let i = 0; i < arrRow.length; i++) {
      if (arrRow[i] || i === 0 || i === arrRow.length - 1) {
        if (startIndex === -1) {
          startIndex = i;
        } else if (endIndex === -1) {
          endIndex = i;
        }

        if (startIndex !== -1 && endIndex !== -1) {
          if ((endIndex - startIndex) > maxDistance) {
            return [startIndex, endIndex];
          } else {
            startIndex = endIndex;
            endIndex = -1;
          }
        }
      }
    }

    return [-1, -1];
  }

  getDistanceToTrue(arr, pos) {
    if (arr[pos]) {
      return 0;
    }

    for (let i = 1; i < arr.length; i++) {
      if (pos - i >= 0 && arr[pos - i]) {
        return i;
      }
      if (pos + i < arr.length && arr[pos + i]) {
        return i;
      }
    }

    return arr.length;
  }
}
