/* 
  Title: Image Mapping with Glitch Satin (B&W)
  Description: Upload an image and map on woven pattern to color areas

  -Setup (see IMAGE PARAMETERS)-
  1. Upload image to data folder
  2. Choose the pattern for the black and white color regions
  3. Modify pixelDetail, blackScaler, and whiteScaler based on image

  -How To Use-
  Click the grid reveal the photo
*/

// global setup
let width = 500; 
let height = 500;
let drawdown_width = width;
let drawdown_height = height;
let cellSize = 10;

// draft setup
let wefts = Math.floor(drawdown_height / cellSize); // Rows
let warps = Math.floor(drawdown_width / cellSize);  // Columns

// image and pattern setup
let img;
let isImageLoaded = false;
let showImage = false;
let gridMask;
let blackPattern, whitePattern;

// == IMAGE + PATTERN PARAMETERS ==
let pixelDetail = 1; // 1 = read every pixel. 5 = every 5th pixel, etc
let blackScaler = 1;
let whiteScaler = 1;

// Define min and max values for black and white patterns
let minForBlack = 1; // Minimum number of unfilled cells in black areas
let maxForBlack = 7; // Maximum number of unfilled cells in black areas
let minForWhite = 10; // Minimum number of unfilled cells in white areas
let maxForWhite = 30; // Maximum number of unfilled cells in white areas


function preload() {
  img = loadImage("data/circle.png", img => {
    isImageLoaded = true;
  });
}

function setup() {
  if (!isImageLoaded) return;

  createCanvas(width, height);
  
  // Setup the image mask
  gridMask = new ImageMask(img);

  // Instantiate two GlitchSatin objects
  blackPattern = new GlitchSatin();
  whitePattern = new GlitchSatin();
}

function draw() {
  background(255);
  
  // generate with min and max
  blackPattern.generateGlitch(minForBlack, maxForBlack);
  whitePattern.generateGlitch(minForWhite, maxForWhite);
  
  // display patterns based on mask
  gridMask.displayPattern(blackPattern, whitePattern);
  
  noLoop();
}

function mouseClicked() {
  showImage = !showImage;
  if (showImage) {
    // Show the image with 50% opacity
    tint(255, 127); // 50% opacity
    image(img, 0, 0, width, height);
    noTint();
  } else {
    redraw();
  }
}