/* 
  Title: Image Mapping with Satin and Tabby (B&W)
  Description: Upload an image and map on woven pattern to color areas

  -Setup (see IMAGE PARAMETERS)-
  1. Upload image to data folder
  2. Choose the pattern for the black and white color regions
  3. Modify pixelDetail, blackScaler, and whiteScaler based on image

  -How To Use-
  Click the grid reveal the photo
*/

// global setup
let width = 500; 
let height = 500;
let drawdown_width = width;
let drawdown_height = height;
let cellSize = 10;

// draft setup
let wefts = Math.floor(drawdown_height / cellSize); // Rows
let warps = Math.floor(drawdown_width / cellSize);  // Columns

// image and pattern setup
let img;
let isImageLoaded = false;
let showImage = false;
let gridMask;
let satinPattern, tabbyPattern;

// == IMAGE PARAMETERS ==
let pixelDetail = 1; // 1 = read every pixel. 5 = every 5th pixel, etc
let blackScaler = 2;
let whiteScaler = 1;

function preload() {
  img = loadImage("data/diffraction.jpg", img => {
    isImageLoaded = true;
  });
}

function setup() {
  if (!isImageLoaded) return;

  createCanvas(width, height);
  
  // setup image mask grid
  gridMask = new ImageMask(img);
  
  // setup patterns
  satinPattern = new Satin(); 
  tabbyPattern = new Tabby();
  satinPattern.generatePatternArray(wefts, warps);
  tabbyPattern.generatePatternArray(wefts, warps);
}

function draw() { 
  background(255);
  
  // display patterns based on mask
  gridMask.displayPattern(tabbyPattern, satinPattern);
  
  // Show the image with 50% opacity
  if (showImage) {
    tint(255, 127); // 50% opacity
    image(img, 0, 0, width, height);
    noTint();
  }
  
  noLoop();
}

function mouseClicked() {
  console.log("Canvas clicked");
  showImage = !showImage;
  redraw();
}