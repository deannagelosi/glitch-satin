class Satin {
  constructor(_repeat = 5, _move = 2) {
    this.repeat = _repeat;
    this.move = _move;
    
    this.grid = []
  }

  generatePatternArray(wefts, warps) {
    // setup the pattern
    for (let i = 0; i < wefts; i++) {
      this.grid[i] = []; 
      let fillPosition = (this.repeat - (i * this.move) % this.repeat) % this.repeat;
      for (let j = 0; j < warps; j++) {
        this.grid[i][j] = (j % this.repeat === fillPosition) ? true : false;
      }
    }
  }
}
