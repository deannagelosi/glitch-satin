class ImageMask {
  constructor(_img) {
    this.img = _img;
    this.grid = [];
    
    // Create image mask
    for (let i = 0; i < wefts; i++) {
      this.grid[i] = [];
      for (let j = 0; j < warps; j++) {
        this.grid[i][j] = this.getAverageCellBW(i, j);
      }
    }
  }
  
  displayPattern(pattern1, pattern2) {
    // loop the mask and apply the patterns based on the mask
    for (let i = 0; i < wefts; i++) {
      for (let j = 0; j < warps; j++) {

        if (this.grid[i][j]) { // mask says black
          if (pattern1.grid[i][j]) {
            fill(0); // black
          } else {
            fill(255); // white
          }
        } 
        else if (!this.grid[i][j]){ // mask says white
          if (pattern2.grid[i][j]) {
            fill(0); // black  
          } else {
            fill(255); // white
          }
        }
        rect(j * cellSize, i * cellSize, cellSize, cellSize);
      }
    }
  }
  
  getAverageCellBW(weft, warp) {
    // Check if the pixels in the cell are more black or more white
    let totalBlack = 0;
    let totalWhite = 0;

    // pixel coords for cell top corner = canvas percentage * image dimension
    let cellX = floor(((warp * cellSize) / drawdown_width) * this.img.width);
    let cellY = floor(((weft * cellSize) / drawdown_height) * this.img.height);

    // loop through all pixels in the cell starting in the top corner
    for (let i = cellX; i < cellX + cellSize; i = i + pixelDetail) {
      for (let j = cellY; j < cellY + cellSize; j = j + pixelDetail) {
        let colorArr = this.img.get(i, j);
        let pRed = colorArr[0];
        let pGreen = colorArr[1];
        let pBlue = colorArr[2];

        let distToBlack = dist(pRed, pGreen, pBlue, 0, 0, 0) * blackScaler;
        let distToWhite = dist(pRed, pGreen, pBlue, 255, 255, 255) * whiteScaler;
        if (distToBlack < distToWhite) {
          totalBlack += 1;
        } else {
          totalWhite += 1;
        }
      }
    }

    // More white or black in the cell?
    if (totalBlack >= totalWhite) {
      return true; // return true for black
    } else {
      return false; //  return false for white
    }
  }
}
