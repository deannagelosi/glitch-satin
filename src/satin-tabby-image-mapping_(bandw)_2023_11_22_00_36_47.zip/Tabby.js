class Tabby {
  constructor() {
    this.grid = []
  }
  
  generatePatternArray(wefts, warps) {
    // setup the pattern
    for (let i = 0; i < wefts; i++) {
      this.grid[i] = [];
      for (let j = 0; j < warps; j++) {
        this.grid[i][j] = (i + j) % 2 == 0 ? true : false;
      }
    }
    
  }
}